#!/bin/bash

SERVICE=$1
STORAGE=$2

if [[ ${SERVICE} == "collector" ]]; then
    echo "Running collector"
    exec python -m collector -s ${STORAGE}

else
    echo "Unknown service ${SERVICE}"
fi
